create view main_view (country_name, year, gdp, social_support, freedom, trust, generosity, happiness_score) as
SELECT c.name AS country_name,
       d.year,
       happiness_report.gdp,
       happiness_report.social_support,
       happiness_report.freedom,
       happiness_report.trust,
       happiness_report.generosity,
       happiness_report.happiness_score
FROM adiscoursework.happiness_report
         JOIN adiscoursework.date d ON d.id = happiness_report.date_id
         JOIN adiscoursework.country c ON c.id = happiness_report.country_id
WHERE happiness_report.energy_consumption IS NOT NULL
  AND d.year >= 2015
  AND d.year <= 2019
  AND happiness_report.total_deaths IS NOT NULL
  AND c.area IS NOT NULL;

alter table main_view
    owner to postgres;

