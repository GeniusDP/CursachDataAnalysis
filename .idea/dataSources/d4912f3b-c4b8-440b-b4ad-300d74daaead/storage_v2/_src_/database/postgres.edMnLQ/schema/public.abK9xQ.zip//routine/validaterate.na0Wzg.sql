create function validaterate(rate smallint) returns boolean
    language plpgsql
as
$$
BEGIN
        RETURN rate >= 0 AND rate <= 100;
    END;
$$;

alter function validaterate(smallint) owner to postgres;

