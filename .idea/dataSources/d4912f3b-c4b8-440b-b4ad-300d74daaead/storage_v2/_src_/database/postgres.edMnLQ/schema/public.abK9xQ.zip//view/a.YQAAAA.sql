create view a(sum) as
SELECT sum(payedtax.count) AS sum
FROM payedtax
         JOIN payer ON payedtax.registrationid = payer.registrationid
WHERE (payedtax.quarter::text = '4'::text OR
       payedtax.date >= '2021-09-15'::date AND payedtax.date <= '2021-12-31'::date)
  AND payer.name::text ~ similar_to_escape('%ав%'::text)
  AND ((SELECT count(*) AS count
        FROM necessarytaxes
        WHERE necessarytaxes.registrationid = payer.registrationid)) = 1;

alter table a
    owner to postgres;

