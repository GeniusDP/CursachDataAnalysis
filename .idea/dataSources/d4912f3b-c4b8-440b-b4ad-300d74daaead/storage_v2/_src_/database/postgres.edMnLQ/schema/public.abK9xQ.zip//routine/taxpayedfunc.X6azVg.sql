create function taxpayedfunc() returns trigger
    language plpgsql
as
$$
BEGIN
        RAISE NOTICE 'Tax has been payed: %', NEW.ID;
        RETURN NEW;
    END;
$$;

alter function taxpayedfunc() owner to postgres;

