create function active_subscribers() returns bigint
    language plpgsql
as
$$
DECLARE
 -- variable for the following BEGIN ... END block
 subscribers integer;
BEGIN
 -- SELECT must always be used with INTO
 SELECT COUNT(user_id) INTO subscribers FROM staff WHERE subscribed;
 -- function result
 RETURN subscribers;
EXCEPTION
 -- return NULL if table "users" does not exist
 WHEN undefined_table
 THEN RETURN NULL;
END;
$$;

alter function active_subscribers() owner to postgres;

