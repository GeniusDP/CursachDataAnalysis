create view country_classification
            (country_name, year, gdp, freedom, trust, generosity, "Malaria", "Drug use disorders", "HIV/AIDS",
             category) as
SELECT the_most_main_view.country_name,
       the_most_main_view.year,
       the_most_main_view.gdp,
       the_most_main_view.freedom,
       the_most_main_view.trust,
       the_most_main_view.generosity,
       the_most_main_view."Malaria",
       the_most_main_view."Drug use disorders",
       the_most_main_view."HIV/AIDS",
       the_most_main_view.category
FROM adiscoursework.the_most_main_view
         JOIN adiscoursework.country ON country.name::text = the_most_main_view.country_name::text
WHERE the_most_main_view.category IS NOT NULL;

alter table country_classification
    owner to postgres;

