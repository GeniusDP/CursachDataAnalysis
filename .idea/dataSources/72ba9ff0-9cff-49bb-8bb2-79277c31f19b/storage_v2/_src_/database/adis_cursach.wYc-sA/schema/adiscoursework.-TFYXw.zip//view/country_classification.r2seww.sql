create view country_classification
            (country_name, year, social_support, gdp, freedom, trust, generosity, "Malaria", "Neoplasms",
             "Drug use disorders", "HIV/AIDS", happiness_score, category)
as
SELECT the_most_main_view.country_name,
       the_most_main_view.year,
       the_most_main_view.social_support,
       the_most_main_view.gdp,
       the_most_main_view.freedom,
       the_most_main_view.trust,
       the_most_main_view.generosity,
       the_most_main_view."Malaria",
       the_most_main_view."Neoplasms",
       the_most_main_view."Drug use disorders",
       the_most_main_view."HIV/AIDS",
       the_most_main_view.happiness_score,
       country.category
FROM adiscoursework.the_most_main_view
         JOIN adiscoursework.country ON country.name::text = the_most_main_view.country_name::text
WHERE the_most_main_view.year = 2016;

alter table country_classification
    owner to postgres;

