create view deaths_reasons_influence_on_happiness
            (name, year, "Malaria", "Neoplasms", "Drug use disorders", "Diarrheal diseases", "HIV/AIDS",
             "Acute hepatitis", happiness_score)
as
SELECT country.name,
       date.year,
       death_report."Malaria"::double precision /
       (country.average_population::real - ((2020 - date.year) * country.net_population_change)::double precision) *
       10000::double precision AS "Malaria",
       death_report."Neoplasms"::double precision /
       (country.average_population::real - ((2020 - date.year) * country.net_population_change)::double precision) *
       10000::double precision AS "Neoplasms",
       death_report."Drug use disorders"::double precision /
       (country.average_population::real - ((2020 - date.year) * country.net_population_change)::double precision) *
       10000::double precision AS "Drug use disorders",
       death_report."Diarrheal diseases"::double precision /
       (country.average_population::real - ((2020 - date.year) * country.net_population_change)::double precision) *
       10000::double precision AS "Diarrheal diseases",
       death_report."HIV/AIDS"::double precision /
       (country.average_population::real - ((2020 - date.year) * country.net_population_change)::double precision) *
       10000::double precision AS "HIV/AIDS",
       death_report."Acute hepatitis"::double precision /
       (country.average_population::real - ((2020 - date.year) * country.net_population_change)::double precision) *
       10000::double precision AS "Acute hepatitis",
       death_report.happiness_score
FROM adiscoursework.death_report
         JOIN adiscoursework.country ON death_report.country_id = country.id
         JOIN adiscoursework.date ON death_report.date_id = date.id;

alter table deaths_reasons_influence_on_happiness
    owner to postgres;

