create view the_most_main_view
            (country_name, year, social_support, gdp, freedom, trust, generosity, "Malaria", "Neoplasms",
             "Drug use disorders", "HIV/AIDS", happiness_score)
as
SELECT deaths_reasons_influence_on_happiness.name AS country_name,
       main_view.year,
       main_view.social_support,
       main_view.gdp,
       main_view.freedom,
       main_view.trust,
       main_view.generosity,
       deaths_reasons_influence_on_happiness."Malaria",
       deaths_reasons_influence_on_happiness."Neoplasms",
       deaths_reasons_influence_on_happiness."Drug use disorders",
       deaths_reasons_influence_on_happiness."HIV/AIDS",
       main_view.happiness_score
FROM adiscoursework.deaths_reasons_influence_on_happiness
         JOIN adiscoursework.main_view
              ON main_view.country_name::text = deaths_reasons_influence_on_happiness.name::text AND
                 main_view.year = deaths_reasons_influence_on_happiness.year;

alter table the_most_main_view
    owner to postgres;

