create view the_most_main_view
            (country_name, year, gdp, freedom, trust, generosity, "Malaria", "Drug use disorders", "HIV/AIDS",
             happiness_score, category)
as
SELECT deaths_reasons_influence_on_happiness.name AS country_name,
       main_view.year,
       main_view.gdp,
       main_view.freedom,
       main_view.trust,
       main_view.generosity,
       deaths_reasons_influence_on_happiness."Malaria",
       deaths_reasons_influence_on_happiness."Drug use disorders",
       deaths_reasons_influence_on_happiness."HIV/AIDS",
       main_view.happiness_score,
       main_view.category
FROM adiscoursework.deaths_reasons_influence_on_happiness
         JOIN adiscoursework.main_view
              ON main_view.country_name::text = deaths_reasons_influence_on_happiness.name::text AND
                 main_view.year = deaths_reasons_influence_on_happiness.year
WHERE deaths_reasons_influence_on_happiness."HIV/AIDS" <= 40::double precision
  AND deaths_reasons_influence_on_happiness."Drug use disorders" <= 1.4::double precision;

alter table the_most_main_view
    owner to postgres;

