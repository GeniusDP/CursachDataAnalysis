create view b(registrationid, name, type, address) as
SELECT payer.registrationid,
       payer.name,
       payer.type,
       payer.address
FROM payer
WHERE (payer.name::text IN (SELECT payer_1.name
                            FROM payer payer_1
                            GROUP BY payer_1.name
                            HAVING count(*) > 1))
  AND NOT (EXISTS(SELECT payedtax.tax_code,
                         count(*) AS count
                  FROM payedtax
                           JOIN payer payer_1 ON payedtax.registrationid = payer_1.registrationid
                  WHERE (payer_1.name::text IN (SELECT payer_2.name
                                                FROM payer payer_2
                                                GROUP BY payer_2.name
                                                HAVING count(*) > 1))
                  GROUP BY payedtax.tax_code
                  HAVING NOT count(*) = 1));

alter table b
    owner to postgres;

