create view c(tax_code, pay_sum) as
SELECT payedtax.tax_code,
       sum(payedtax.count) AS pay_sum
FROM payedtax
WHERE date_part('year'::text, payedtax.date) = 2021::double precision
  AND (((SELECT payer.type
         FROM payer
         WHERE payer.registrationid = payedtax.registrationid))::text) = 'Приватний підприємець'::text
GROUP BY payedtax.tax_code
ORDER BY (sum(payedtax.count));

alter table c
    owner to postgres;

