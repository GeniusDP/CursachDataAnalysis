create view d(tax_code, pay_sum) as
SELECT payedtax.tax_code,
       sum(payedtax.count) AS pay_sum
FROM payedtax
WHERE date_part('year'::text, payedtax.date) = 2021::double precision
GROUP BY payedtax.tax_code
ORDER BY (sum(payedtax.count)) DESC
LIMIT 2;

alter table d
    owner to postgres;

